package xn.model;



public class x_Net {
	private double speed;//网口速度
	private  double sendrate;
	private  double receiverate;
	private  String DNS;
	private  String IPV4;
	private  String IPV6;
	
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	public double getSendrate() {
		return sendrate;
	}
	public void setSendrate(double sendrate) {
		this.sendrate = sendrate;
	}
	public double getReceiverate() {
		return receiverate;
	}
	public void setReceiverate(double receiverate) {
		this.receiverate = receiverate;
	}
	public String getDNS() {
		return DNS;
	}
	public void setDNS(String dNS) {
		DNS = dNS;
	}
	public String getIPV4() {
		return IPV4;
	}
	public void setIPV4(String iPV4) {
		IPV4 = iPV4;
	}
	public String getIPV6() {
		return IPV6;
	}
	public void setIPV6(String iPV6) {
		IPV6 = iPV6;
	}
	
	
	

}
