package xn.model;

public class Cipan_model {
	private  String cipan_size;
	private  String cipan_name;
	private  String speed;
	public String getCipan_size() {
		return cipan_size;
	}
	public void setCipan_size(String cipan_size) {
		this.cipan_size = cipan_size;
	}
	public String getCipan_name() {
		return cipan_name;
	}
	public void setCipan_name(String cipan_name) {
		this.cipan_name = cipan_name;
	}
	public String getSpeed() {
		return speed;
	}
	public void setSpeed(String speed) {
		this.speed = speed;
	}
	

}
